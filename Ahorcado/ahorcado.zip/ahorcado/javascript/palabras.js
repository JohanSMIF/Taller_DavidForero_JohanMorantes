const words = ['Carne','Martillo', 
'Lavadora','Sucio',
'Cangrejo','Lento',
'Alimentos','Delgado',
'Cubo','Comida','Caracol',
'Abajo','Alumno','Bonito',
'Cesta','Sol','Beber','Botella',
'Hamburguesa','Invierno'];